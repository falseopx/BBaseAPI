﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseAPI
{


    //        _            _          _      _                  _          _                   _        _
    //       / /\         /\ \       /\ \   /\_\               /\ \       / /\                /\ \     /\ \   
    //      / /  \       /  \ \      \_\ \ / / /         _    /  \ \     / /  \              /  \ \    \ \ \  
    //     / / /\ \__   / /\ \ \     /\__ \\ \ \__      /\_\ / /\ \ \   / / /\ \            / /\ \ \   /\ \_\ 
    //    / / /\ \___\ / / /\ \_\   / /_ \ \\ \___\    / / // / /\ \_\ / / /\ \ \          / / /\ \_\ / /\/_/ 
    //    \ \ \ \/___// /_/_ \/_/  / / /\ \ \\__  /   / / // / /_/ / // / /  \ \ \        / / /_/ / // / /    
    //     \ \ \     / /____/\    / / /  \/_// / /   / / // / /__\/ // / /___/ /\ \      / / /__\/ // / /     
    // _    \ \ \   / /\____\/   / / /      / / /   / / // / /_____// / /_____/ /\ \    / / /_____// / /      
    ///_/\__/ / /  / / /______  / / /      / / /___/ / // / /      / /_________/\ \ \  / / /   ___/ / /__     
    //\ \/___/ /  / / /_______\/_/ /      / / /____\/ // / /      / / /_       __\ \_\/ / /   /\__\/_/___\    
    // \_____\/   \/__________/\_\/       \/_________/ \/_/       \_\___\     /____/_/\/_/    \/_________/


    //This is where you setup your API to work with your DLL.


    public class SetupAPI
    {
        // API Name is the name of your API
        public static string APIName = "BaseAPI";

        // API Install Link is where the API installs your DLL from
        public static string APIInstallLink = "InsertAPILink";

        // DLL Name is the name of the DLL so the API can interface with it
        public static string DLLName = "BaseAPI.dll";

        // DLL Pipe is the name of the DLL Pipe so the API can execute the DLL
        public static string DLLPipe = "InsertAPIHere";
    }
}
