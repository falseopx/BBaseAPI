﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaseAPI
{


    //        _      _        _         _          _            _           _   _       
    //       / /\   /\ \     /\_\      / /\       /\ \         /\ \        /\_\/\_\ _   
    //      / /  \  \ \ \   / / /     / /  \      \_\ \       /  \ \      / / / / //\_\ 
    //     / / /\ \__\ \ \_/ / /     / / /\ \__   /\__ \     / /\ \ \    /\ \/ \ \/ / / 
    //    / / /\ \___\\ \___/ /     / / /\ \___\ / /_ \ \   / / /\ \_\  /  \____\__/ /  
    //    \ \ \ \/___/ \ \ \_/      \ \ \ \/___// / /\ \ \ / /_/_ \/_/ / /\/________/   
    //     \ \ \        \ \ \        \ \ \     / / /  \/_// /____/\   / / /\/_// / /    
    // _    \ \ \        \ \ \   _    \ \ \   / / /      / /\____\/  / / /    / / /     
    ///_/\__/ / /         \ \ \ /_/\__/ / /  / / /      / / /______ / / /    / / /      
    //\ \/___/ /           \ \_\\ \/___/ /  /_/ /      / / /_______\\/_/    / / /       
    // \_____\/             \/_/ \_____\/   \_\/       \/__________/        \/_/       


    //Just some required stuff that would seem a bit cluttered to put on Exploit.cs


    public class System
    {
        #region Inject
        public static void Inject()
        {
            var puppyMilk = new ProcessStartInfo(Directory.GetCurrentDirectory() + "\\bin\\Injector.exe");
            puppyMilk.Arguments = Directory.GetCurrentDirectory() + "\\bin\\" + SetupAPI.DLLName;
            puppyMilk.CreateNoWindow = false;
            Process.Start(puppyMilk).WaitForExit();
        }
        #endregion
        #region Does Pipe Exist

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool WaitNamedPipe(string name, int timeout);

        public static bool DoesPipeExist(string pipeName)
        {
            bool result;
            try
            {
                bool flag = !System.WaitNamedPipe("\\\\.\\pipe\\" + pipeName, 0);
                if (flag)
                {
                    int lastWin32Error = Marshal.GetLastWin32Error();
                    bool flag2 = lastWin32Error == 0;
                    if (flag2)
                    {
                        return false;
                    }
                    bool flag3 = lastWin32Error == 2;
                    if (flag3)
                    {
                        return false;
                    }
                }
                result = true;
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }

        #endregion
        #region ExecuteToPipe
        public static void ExecuteToPipe(string script)
        {
            bool flag = System.DoesPipeExist(SetupAPI.DLLPipe);
            if (flag)
            {
                new Thread(delegate ()
                {
                    try
                    {
                        using (NamedPipeClientStream namedPipeClientStream = new NamedPipeClientStream(".", SetupAPI.DLLPipe, PipeDirection.Out))
                        {
                            namedPipeClientStream.Connect();
                            using (StreamWriter streamWriter = new StreamWriter(namedPipeClientStream, Encoding.Default, 999999))
                            {
                                streamWriter.Write(script);
                                streamWriter.Dispose();
                            }
                            namedPipeClientStream.Dispose();
                        }
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("Cannot connect to the pipe, please ask the API Developer!", SetupAPI.APIName);
                    }
                    catch (Exception)
                    {

                    }
                }).Start();
            }
            else
            {
                MessageBox.Show("Please inject " + SetupAPI.APIName, SetupAPI.APIName);
            }
        }
        #endregion

    }
}
